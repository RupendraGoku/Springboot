package com.blogspot.mySpringProject.journalApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JournalApplicationTests {

	@Test
	void contextLoads() {
	}

}
