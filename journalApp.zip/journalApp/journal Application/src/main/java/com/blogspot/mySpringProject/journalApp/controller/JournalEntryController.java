package com.blogspot.mySpringProject.journalApp.controller;

public class JournalEntryController {
}
